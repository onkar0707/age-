"""Entry point for running agent_docstrings as a module with python -m."""

from .cli import main

if __name__ == "__main__":
    main() 