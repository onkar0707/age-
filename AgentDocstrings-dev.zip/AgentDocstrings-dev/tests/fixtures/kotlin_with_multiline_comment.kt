/**
 * This is a multi-line comment that should be preserved.
 * It exists to test the header preservation logic.
 */
package com.example

class MyClass {
    fun myMethod() {
        // method body
    }
} 