"""This is a manual docstring.
It has multiple lines.
The generator should not break it.
"""

class MyClass:
    """A simple example class."""
    def my_method(self, arg1: int) -> str:
        """A simple example method."""
        return f"Hello {arg1}" 